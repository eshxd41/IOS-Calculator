//
//  calculatorBrain.swift
//  calculator
//
//  Created by Guest User on 24/11/17.
//  Copyright © 2017 suresh. All rights reserved.
//

import Foundation


struct Brain{
    
    var accumulator: Double?

    func peformOperation(_ symbol: String){
    
    }
    mutating func setOperand(_ operand: String){
        
        
        
        if  let number = Double(operand){ // if the number is double operand then it will print Number touch orelse oper
            print("\(operand) Number touched")
        }
        else {
            print("\(operand) operation Touched")// if number is +/=* this message is displayed
        
        }
        
        var result: Double!{
            
            get{
                return accumulator
                
            }
        }
        
//        accumulator = Double(operand)!  
    
    }
    
    
}
