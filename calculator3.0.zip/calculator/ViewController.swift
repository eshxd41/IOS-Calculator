//
//  ViewController.swift
//  calculator
//
//  Created by Guest User on 06/11/17.
//  Copyright © 2017 suresh. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var display: UILabel!// in var place we can use 'let' and display.. and : it teslls me where   amd there is is ! is becuse we know the label           exits ..since we know that it exits..
    
    var brain: Brain = Brain()
    
    @IBAction func digitTouch(_ sender: UIButton) { // IBaction what ever the  conected
                                                    //the aurg  are commposed of two words  it means when we pass a veriable it will take it
                                                    //sender: 
                                                    //UIbutton:
        
        brain.setOperand(sender.currentTitle!)
        
        
        
        
        
    }
    
    
    }

    



